using System;
using Asp.Versioning;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using ShoppingCartApp.Data;


namespace ShoppingCartApp.Controllers.API
{
    [ApiController]
    [ApiVersion("1.0")]
    [Route("api/v{version:apiVersion}/admin/orders")]
    [Authorize(
        AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme,
        Roles = "admin"
    )]
    public class AdminOrdersApiController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public AdminOrdersApiController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public IActionResult GetAllOrders()
        {
            return Ok(
                _context.Orders
                    .OrderByDescending(o => o.CreatedAt)
                    .ToList()
            );
        }
    }

}