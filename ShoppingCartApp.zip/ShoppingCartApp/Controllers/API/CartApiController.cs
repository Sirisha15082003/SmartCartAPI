using Asp.Versioning;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Authentication.JwtBearer;


namespace ShoppingCartApp.Controllers.API
{
    
    [ApiController]
    [ApiVersion("1.0")]
    [Route("api/v{version:apiVersion}/cart")]
    [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    public class CartApiController : ControllerBase
    {
        [HttpPost("add")]
        public IActionResult AddToCart(int productId, int quantity)
        {
            // In future: cart service or Redis
            return Ok("Item added to cart (placeholder)");
        }
    }

}