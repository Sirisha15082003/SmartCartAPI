using System.ComponentModel.DataAnnotations;

namespace ShoppingCartApp.Models
{
    public class CheckoutDTO
    {
        [Required(ErrorMessage = "The Delivery Address is required.")]
        [MaxLength(200)]
        public string DeliveryAddress { get; set; } = "";
        public string PaymentMethod { get; set; } = "";
    }
}
